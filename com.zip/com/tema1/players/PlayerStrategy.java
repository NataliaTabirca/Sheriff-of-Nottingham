package com.tema1.players;

public enum PlayerStrategy { basic, greedy, bribed }
