package com.tema1.players;

public enum PlayerType { sheriff, merchant }
