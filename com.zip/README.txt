Tabirca Natalia-Mihaela 322CA

Am creat 3 pachete suplimentare care au urmatoarea structura
    - player
            ~ clasele:  Player -> contine campuri si metode specifice jucatorului pentru 
                            crearea sacului, a tarabei, adugarea cartilor etc.,
                            getters & setters, metode de afisare
                        AllPlayers -> metode de adaugare si sorare a jucatorilor,
                            afisarea clasamentului si getters 
                        Bonuses -> adaugare legalBonus si illegalBonus

            ~ clasele pentru comparator:    PlayersComparator -> sorteaza dupa banii acumulati
                                            ProfitComparator -> sorteaza dupa profit bunurile ilegale,
                                                iar pe cele legale, dupa id
                                            SortComparator -> sorteaza cartile dupa id

            ~ enumeratorii: PlayerStrategy -> contine cele 3 strategii de joc
                            PlayerType -> contine rolurile jucatorilor        
             
    - strategies -> sunt implementate crearea sacului si verificarea sa in fiecare 
                din cele 3 clasele
            ~ clasele:  BasicStrategy
                        GreedyStrategy
                        BribedStrategy
    - deckOfCards
            ~ clasa:    DeckOfCards -> implementeaza pachetul initial de cartile


Metoda main din clasa Main este structurata astfel:
    - citesc datele, adaugand jucatorii intr-un ArrayList de tip Player si
  cartile intr-un ArrayList de tip deckOfCards
    - parcurg fiecare runda si subrunda atribuind rolul de serif si facand
  operatiile necesare de adaugare pe taraba
    - la final adaug bonusul pentru bunurile ilegale, apoi pentru cele legale
    - adaug profitul
    - sortez jucatorii si afisez clasamentul 